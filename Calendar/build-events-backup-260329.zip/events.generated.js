window.CALENDAR_EVENTS = [
  {
    "id": "2. Projektverwaltung/2026 TOHU VHS - Zirkus Kröllwitz/Ferienwoche 1 Kröllwitz.md",
    "title": "Ferienwoche 1 Kröllwitz",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU VHS - Zirkus Kröllwitz/Ferienwoche 1 Kröllwitz.md"
    },
    "start": "2026-02-02",
    "end": "2026-02-07",
    "backgroundColor": "red",
    "borderColor": "red"
  },
  {
    "id": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 3.md",
    "title": "Zirkus Waldstadt - Ferienwoche 3",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 3.md"
    },
    "start": "2026-02-16",
    "end": "2026-02-21",
    "backgroundColor": "cyan",
    "borderColor": "cyan"
  },
  {
    "id": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 4.md",
    "title": "Zirkus Waldstadt - Ferienwoche 4",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 4.md"
    },
    "start": "2026-02-16",
    "end": "2026-02-21",
    "backgroundColor": "cyan",
    "borderColor": "cyan"
  },
  {
    "id": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 5.md",
    "title": "Zirkus Waldstadt - Ferienwoche 5",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 5.md"
    },
    "start": "2026-02-16",
    "end": "2026-02-21",
    "backgroundColor": "cyan",
    "borderColor": "cyan"
  },
  {
    "id": "2. Projektverwaltung/2026 TOHU JEP - Waldstadt Artisten/Kurs 1 JEP.md",
    "title": "Kurs 1 JEP",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU JEP - Waldstadt Artisten/Kurs 1 JEP.md"
    },
    "start": "2026-02-23",
    "end": "2026-02-24",
    "backgroundColor": "red",
    "borderColor": "red"
  },
  {
    "id": "2. Projektverwaltung/2026 NICA JEP - Bühnenreif/Kurs Dornrößchen.md",
    "title": "Kurs Dornrößchen",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 NICA JEP - Bühnenreif/Kurs Dornrößchen.md"
    },
    "start": "2026-02-23",
    "end": "2026-02-24",
    "backgroundColor": "red",
    "borderColor": "red"
  },
  {
    "id": "2. Projektverwaltung/2026 NICA ZMS - Zirkus Waldstadt/Zirkus Waldstadt - Workshop.md",
    "title": "Zirkus Waldstadt - Workshop",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 NICA ZMS - Zirkus Waldstadt/Zirkus Waldstadt - Workshop.md"
    },
    "start": "2026-03-27",
    "end": "2026-03-29",
    "backgroundColor": "cyan",
    "borderColor": "cyan"
  },
  {
    "id": "6. Obsidian/Inbox/Calendar Event Test.md",
    "title": "Calendar Event Test",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Calendar Event Test.md",
      "isRecurring": true
    },
    "daysOfWeek": [
      1,
      4
    ],
    "startRecur": "2026-03-30",
    "endRecur": "2026-07-01",
    "editable": false,
    "backgroundColor": "#0f766e",
    "borderColor": "#0f766e"
  },
  {
    "id": "2. Projektverwaltung/2026 NICA JEP - Bühnenreif/Ferienwoche Dornrößchen.md",
    "title": "Ferienwoche Dornrößchen",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 NICA JEP - Bühnenreif/Ferienwoche Dornrößchen.md"
    },
    "start": "2026-03-30",
    "end": "2026-04-04",
    "backgroundColor": "red",
    "borderColor": "red"
  },
  {
    "id": "6. Obsidian/Inbox/Osterferien 2026.md",
    "title": "Osterferien 2026",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Osterferien 2026.md"
    },
    "start": "2026-03-30",
    "end": "2026-04-04",
    "backgroundColor": "orange",
    "borderColor": "orange",
    "display": "background"
  },
  {
    "id": "2. Projektverwaltung/2026 NICA - Zirkustreffen Nord/Workshop Zirkustreffen Nord.md",
    "title": "Workshop Zirkustreffen Nord",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 NICA - Zirkustreffen Nord/Workshop Zirkustreffen Nord.md"
    },
    "start": "2026-05-17",
    "end": "2026-05-22",
    "backgroundColor": "red",
    "borderColor": "red"
  },
  {
    "id": "6. Obsidian/Inbox/Pfingstferien 2026.md",
    "title": "Pfingstferien 2026",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Pfingstferien 2026.md"
    },
    "start": "2026-05-25",
    "end": "2026-05-30",
    "backgroundColor": "orange",
    "borderColor": "orange",
    "display": "background"
  },
  {
    "id": "2. Projektverwaltung/2026 TOHU ZGV - Wanderzirkus Neustadt/Ferienwoche CVJM Schnitte Ost.md",
    "title": "Ferienwoche CVJM Schnitte Ost",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU ZGV - Wanderzirkus Neustadt/Ferienwoche CVJM Schnitte Ost.md"
    },
    "start": "2026-07-07",
    "end": "2026-07-11",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "6. Obsidian/Inbox/Sommerferien 2026.md",
    "title": "Sommerferien 2026",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Sommerferien 2026.md"
    },
    "start": "2026-07-07",
    "end": "2026-08-16",
    "backgroundColor": "orange",
    "borderColor": "orange",
    "display": "background"
  },
  {
    "id": "2. Projektverwaltung/2026 TOHU ZGV - Wanderzirkus Neustadt/Ferienwoche Roxy.md",
    "title": "Ferienwoche Roxy",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU ZGV - Wanderzirkus Neustadt/Ferienwoche Roxy.md"
    },
    "start": "2026-07-13",
    "end": "2026-07-18",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "2. Projektverwaltung/2026 TOHU OAC - Jahreszeiten-Zirkus/Ferien Passendorfer Kirche.md",
    "title": "Ferien Passendorfer Kirche",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU OAC - Jahreszeiten-Zirkus/Ferien Passendorfer Kirche.md"
    },
    "start": "2026-07-20",
    "end": "2026-07-25",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "6. Obsidian/Inbox/Ferienwoche Schöpfkelle.md",
    "title": "Ferienwoche Schöpfkelle",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Ferienwoche Schöpfkelle.md"
    },
    "start": "2026-07-27",
    "end": "2026-08-01",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "2. Projektverwaltung/2026 TOHU JEP - Waldstadt Artisten/Ferienwoche Blauer Elefant.md",
    "title": "Ferienwoche Blauer Elefant",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "2. Projektverwaltung/2026 TOHU JEP - Waldstadt Artisten/Ferienwoche Blauer Elefant.md"
    },
    "start": "2026-08-03",
    "end": "2026-08-08",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 2.md",
    "title": "Zirkus Waldstadt - Ferienwoche 2",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Zirkus Waldstadt - Ferienwoche 2.md"
    },
    "start": "2026-08-10",
    "end": "2026-08-15",
    "backgroundColor": "blue",
    "borderColor": "blue"
  },
  {
    "id": "6. Obsidian/Inbox/Herbstferien 2026.md",
    "title": "Herbstferien 2026",
    "allDay": true,
    "extendedProps": {
      "sourcePath": "6. Obsidian/Inbox/Herbstferien 2026.md"
    },
    "start": "2026-10-19",
    "end": "2026-10-31",
    "backgroundColor": "orange",
    "borderColor": "orange",
    "display": "background"
  }
];
